SKY PILOT WORLD TOUR 2.0
1. 이 압축파일을 풀어 index.html을 준비합니다.
2. GitHub jsh5686/drone-tour 에 있는 오래된 index.html을 반드시 교체합니다.
3. 휴대폰이 index-1.html 또는 index(1).html로 이름을 바꿨다면 업로드 전 index.html로 이름을 변경합니다.
4. main 브랜치 최상위에 index.html이 있어야 GitHub Pages 기본 주소에서 최신판이 열립니다.
5. 주소: https://jsh5686.github.io/drone-tour/
6. 브이월드 인증키는 웹사이트에서 직접 입력합니다. 로컬 다운로드 파일에서 지도가 연결되지 않을 수 있습니다.
